<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\Product;

class ProductApiTest extends TestCase
{
    use RefreshDatabase; // Mengosongkan database dummy otomatis setiap kali test berjalan

    // UT01 - Get Product
    public function test_get_products()
    {
        $response = $this->get('/api/products');
        $response->assertStatus(200);
    }

    // VT01 - Harga minus harus error (Validation Test)
    public function test_store_product_invalid_price()
    {
        $response = $this->postJson('/api/products', [
            'name'  => 'Buku Pemrograman',
            'price' => -1, // Invalid
            'stock' => 10
        ]);

        $response->assertStatus(422); // Unprocessable Entity
    }

    // VT04 - Input data valid harus sukses
    public function test_store_product_success()
    {
        $response = $this->postJson('/api/products', [
            'name'  => 'Laptop ASUS',
            'price' => 15000000,
            'stock' => 5
        ]);

        $response->assertStatus(201);
        $this->assertDatabaseHas('products', ['name' => 'Laptop ASUS']);
    }
}